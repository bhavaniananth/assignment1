const express =require("express");
const { connect } = require("mongoose");
const app = express();
const connectDB = require('./DB/connection');
connectDB();
app.use(express.json({ extended: false}));
//app.use('/api/model', require('.API/User'));
const port = process.env.port || 3000;
app.listen(port,() => console.log('server started'));
