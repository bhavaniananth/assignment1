const mongoose =require('mongoose');
const URI = "mongodb+srv://<bhavaniananth>:<anuradha.123>@cluster0.e35ai.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
const connectDB =async() => {
    await  mongoose.connect (URI,{
        useUnifiedTopology : true,
        useNewUrlParser:true
                        });
console.log('db connected...!');
                    };
                    module.exports =connectDB;