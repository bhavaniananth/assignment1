const mongoose = require('mongoose');
var book = mongoose.model('book', {
Title:{type: String},
author:{ type : String},
summary:{ type : string},
ISBN:{type: string},
genre: { type : Genre},
url:{type : string}

});
module.exports = book;